﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using StudentCourseResult.Data;
using StudentCourseResult.Models.Entities;
using StudentCourseResult.Models.ViewModels;

namespace StudentCourseResult.Controllers
{
    public class StudentResultsController : Controller
    {
        public readonly ResultDBContext _dbContext;
        public StudentResultsController(ResultDBContext dBContext)
        {
            _dbContext = dBContext;
        }

        public IActionResult Index(string studentStatus)
        {

            IQueryable<ResultEntity> query = _dbContext.Results;

            if (!string.IsNullOrEmpty(studentStatus))
            {
                if (studentStatus == StudentStatus.Excellent.ToString())
                {
                    query = query.Where(d => d.TotalMarks >= 90);
                }
                else if (studentStatus == StudentStatus.Good.ToString())
                {
                    query = query.Where(d => d.TotalMarks >= 50 && d.TotalMarks < 90);
                }
                else if (studentStatus == StudentStatus.NeedsImprovement.ToString())
                {
                    query = query.Where(d => d.TotalMarks < 50);
                }
            }

            var studentsList = query.Select(d => new ResultListViewModel
            {
                StudentName = d.StudentName,
                CourseTitle = d.CourseTitle,
                TotalMarks= d.TotalMarks,
                Status = d.Status.ToString(),
            }).ToList();

            return View(studentsList);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ResultCreateViewModel result)
        {
            if (!ModelState.IsValid)
                return View(result);

            var productEntity = new ResultEntity
            {
                StudentName = result.StudentName,
                CourseTitle = result.CourseTitle,
                TotalMarks = result.TotalMarks,
                Status = result.TotalMarks >= 90 ? StudentStatus.Excellent : (result.TotalMarks >= 50 ? StudentStatus.Good : StudentStatus.NeedsImprovement)
            };

            _dbContext.Add(productEntity);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
