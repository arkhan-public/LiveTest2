﻿using Microsoft.EntityFrameworkCore;
using StudentCourseResult.Models.Entities;

namespace StudentCourseResult.Data
{
    public class ResultDBContext : DbContext
    {
        public ResultDBContext(DbContextOptions<ResultDBContext> options) : base(options)
        {

        }

        public DbSet<ResultEntity> Results { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<ResultEntity>().HasData(
            new ResultEntity
            {
                Id = 1,
                StudentName = "John Doe",
                CourseTitle = "Mathematics",
                TotalMarks = 45,
                Status = StudentStatus.NeedsImprovement
            },
            new ResultEntity
            {
                Id = 2,
                StudentName = "John Smith",
                CourseTitle = "Physics",
                TotalMarks = 75,
                Status = StudentStatus.Good
            },
            new ResultEntity
            {
                Id = 3,
                StudentName = "Mike Johnson",
                CourseTitle = "Chemistry",
                TotalMarks = 92,
                Status = StudentStatus.Excellent
            }, new ResultEntity
            {
                Id = 4,
                StudentName = "Sarah Williams",
                CourseTitle = "Biology",
                TotalMarks = 68,
                Status = StudentStatus.Good
            }, new ResultEntity
            {
                Id = 5,
                StudentName = "David Brown",
                CourseTitle = "Computer Science",
                TotalMarks = 35,
                Status = StudentStatus.NeedsImprovement
            });
        }
    }
}
