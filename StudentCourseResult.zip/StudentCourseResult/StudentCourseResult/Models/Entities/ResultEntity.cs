﻿using System.ComponentModel.DataAnnotations;

namespace StudentCourseResult.Models.Entities
{
    public class ResultEntity
    {
        [Key]
        public int Id { get; set; }
        public required string StudentName { get; set; }
        public required string CourseTitle { get; set; }
        public required int TotalMarks { get; set; }
        public required StudentStatus Status { get; set; }
    }
}
