﻿namespace StudentCourseResult.Models.Entities
{
    public enum StudentStatus
    {
        Excellent,
        Good,
        NeedsImprovement
    }
}
