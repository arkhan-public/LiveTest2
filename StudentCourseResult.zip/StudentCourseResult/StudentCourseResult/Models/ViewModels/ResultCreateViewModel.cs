﻿using StudentCourseResult.Models.Entities;
using System.ComponentModel.DataAnnotations;

namespace StudentCourseResult.Models.ViewModels
{
    public class ResultCreateViewModel
    {
        public required string StudentName { get; set; }
        public required string CourseTitle { get; set; }

        public required int TotalMarks { get; set; }
    }
}
