﻿using StudentCourseResult.Models.Entities;
using System.ComponentModel.DataAnnotations;

namespace StudentCourseResult.Models.ViewModels
{
    public class ResultListViewModel
    {
        public required string StudentName { get; set; }
        public required string CourseTitle { get; set; }

        public required int TotalMarks { get; set; }
        public required string Status { get; set; }
    }
}
